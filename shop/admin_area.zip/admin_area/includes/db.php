<?php

$con = mysqli_connect("localhost","thekings_user","th3k1ngs@2022","thekings_db");

?>